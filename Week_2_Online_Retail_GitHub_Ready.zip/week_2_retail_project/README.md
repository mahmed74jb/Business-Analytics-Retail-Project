# Online Retail Business Performance Analytics

## Week 2 — Data Extraction, Cleaning, and Exploratory Analysis

Student: Muhammad Ahmed

This repository section contains the Week 2 work for the Virtual Business Analytics Trainee Intern project.

### Dataset
The analysis uses the supplied UCI Online Retail II workbook with two sheets:
- Year 2009-2010
- Year 2010-2011

The full source workbook is intentionally not included in this repository because of its size. Use the official UCI source workbook when reproducing the complete analysis.

### Week 2 deliverables
- `docs/Week_2_Data_Cleaning_EDA_Report.docx`
- `notebook/Week_2_Data_Cleaning_EDA.ipynb`
- `outputs/` charts and summary tables
- `data/cleaned_sample_2000.csv`

### Cleaning logic
- Remove exact duplicates
- Parse dates
- Flag cancellation invoices
- Exclude cancellations, non-positive quantities, and non-positive prices from positive-sales KPI analysis
- Fill missing product descriptions with `Unknown Product`
- Preserve missing Customer IDs rather than inventing values
- Review Quantity and Price outliers using IQR
- Create TransactionValue and time features
- Create normalized numerical copies for analytical readiness

### Main Python tools
Pandas, NumPy, Matplotlib, Jupyter Notebook
