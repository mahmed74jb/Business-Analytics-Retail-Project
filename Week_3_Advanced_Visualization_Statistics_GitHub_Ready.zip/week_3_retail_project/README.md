# Week 3 — Advanced Data Visualization and Statistical Analysis

Student: Muhammad Ahmed

This folder contains the Week 3 report, notebook, statistical summaries and visual outputs for the Online Retail Business Performance Analytics project.
