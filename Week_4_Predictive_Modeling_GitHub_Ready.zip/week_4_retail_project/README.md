# Week 4 — Predictive Modeling and Performance Evaluation

## Project
Online Retail Business Performance Analytics

## Objective
Predict whether an identifiable customer will place at least one additional order within 60 days of a monthly customer snapshot.

## Modeling approach
- Customer-level rolling snapshots
- RFM-style behavioral features plus order/product behavior
- Time-based train/test split
- Majority-class baseline
- Logistic Regression benchmark
- Random Forest classifier
- Accuracy, precision, recall, F1-score, ROC-AUC
- Confusion matrix and feature-importance diagnostics

## Key test-period results

| Model | Accuracy | Precision | Recall | F1 | ROC-AUC |
|---|---:|---:|---:|---:|---:|
| Majority baseline | 0.725 | 0.000 | 0.000 | 0.000 | — |
| Logistic Regression | 0.759 | 0.551 | 0.673 | 0.606 | 0.810 |
| Random Forest | 0.781 | 0.600 | 0.618 | 0.609 | 0.814 |

## Files
- `docs/Week_4_Predictive_Modeling_Performance_Evaluation_Report.docx`
- `notebook/Week_4_Predictive_Modeling_Performance_Evaluation.ipynb`
- `outputs/` — charts, metrics, confusion matrix, feature importance
- `models/` — trained model files

## Important modeling note
The target is defined from future purchases, while all predictors are calculated only from information available at the snapshot date. This separation is intentional to reduce target leakage.

## Dataset
UCI Online Retail II.
